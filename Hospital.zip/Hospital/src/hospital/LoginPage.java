package hospital;

import java.util.Scanner;

public class LoginPage {
    private HospitalManagementSystem hms;

    public LoginPage(HospitalManagementSystem hms) {
        this.hms = hms;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Hospital Management System");

        System.out.print("Enter your user ID: ");
        String userID = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        User user = hms.login(userID, password);

        if (user != null) {
            System.out.println("Login successful!");
            displayMenu(user);
        } else {
            System.out.println("Invalid credentials. Please try again.");
        }
    }

    private void displayMenu(User user) {
        if (user instanceof Doctor) {
            DoctorMenu doctorMenu = new DoctorMenu((Doctor) user, hms);
            doctorMenu.display();
        } else if (user instanceof Patient) {
            PatientMenu patientMenu = new PatientMenu((Patient) user, hms);
            patientMenu.display();
        } else if (user instanceof Pharmacist) {
            PharmacistMenu pharmacistMenu = new PharmacistMenu((Pharmacist) user, hms);
            pharmacistMenu.display();
        } else if (user instanceof Administrator) {
            AdministratorMenu adminMenu = new AdministratorMenu((Administrator) user, hms);
            adminMenu.display();
        }
    }
}
