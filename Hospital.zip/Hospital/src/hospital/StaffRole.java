package hospital;

public enum StaffRole {
    DOCTOR,
    PHARMACIST,
    ADMINISTRATOR
}
