package hospital;

public enum UserRole {
    PATIENT,
    STAFF
}