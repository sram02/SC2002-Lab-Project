package hospital;

import java.io.FileNotFoundException;

public class MainApp {
    public static void main(String[] args) {
        HospitalManagementSystem hms = new HospitalManagementSystem();
        
        try {

        	hms.loadPatients();
        	hms.loadStaff();
        	hms.loadMedicines();
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Assuming LoginPage and subsequent navigation will be implemented
        LoginPage loginPage = new LoginPage(hms);
        loginPage.start();
    }
}
