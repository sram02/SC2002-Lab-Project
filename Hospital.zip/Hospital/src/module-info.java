/**
 * 
 */
/**
 * 
 */
module Hospital {
}